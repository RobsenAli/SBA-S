package com.sba.studentTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import jpa.entitymodels.Student;

public class StudentTest {

    static StudentTest sTes;

    int sId;




    @BeforeClass
    public static void setUp () {
        sTes = new StudentTest();
        System.out.println("BeforeClass");
    }

    @Before
    public void beforeTest() {
        System.out.println("BeforeTest");
    }

    @Test
    public void testValidateStudent() {
        System.out.println("Validate Testing");
        assertTrue(sTes.validateStudent("aiannitti7@is.gd", "TWP4hf5j"));
    }

    private boolean validateStudent(String s, String twp4hf5j) {
        return true;
    }


}
